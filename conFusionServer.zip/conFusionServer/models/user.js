var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var passportLocalMongoose = require('passport-local-mongoose');

var User = new Schema({
    //username and password removes bcoz this will be automatically added by passport
    firstname:{
        type: String,
        default: ''
    },
    lastname:{
        type: String,
        default: ''
    },

    admin:   {
        type: Boolean,
        default: false
    }
});

User.plugin(passportLocalMongoose);// this will automatically adding support for username and hashed storage of the password

module.exports = mongoose.model('User', User);